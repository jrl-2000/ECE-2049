/*
 * JRL.h
 *
 *  Created on: Mar 7, 2021
 *      Author: Jonathan Lopez
 */

#ifndef JRL_H_
#define JRL_H_

//#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)
//#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)

//lmao thanks smith for this header file name

// Jonathan Lopez
// ECE 2049
// C term 2021
// Lab 3 Time and Temperature Display

#endif /* JRL_H_ */
